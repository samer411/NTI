const barIcon = document.querySelector(".bar");
const ul = document.querySelector("ul");
const closeIcon = document.querySelector(".close");
const darkModeToggle = document.querySelector(".dark-mode");
const icons = document.querySelector(".dark-mode i");



function showUL() {
    ul.classList.remove("hidden");
    ul.classList.add("flex")
}

function hideUL() {
    ul.classList.add("hidden")
    ul.classList.remove("flex")
}

function makeDarkLight() {
    document.documentElement.classList.toggle("dark");
    if (document.documentElement.classList.contains("dark")) {
        localStorage.setItem("theme", "dark");
    } else {
        localStorage.setItem("theme", "light");
    }
    icons.classList.toggle("fa-moon")
    icons.classList.toggle("fa-sun")

}

if (localStorage.theme === "dark" || (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
    document.documentElement.classList.add("dark");
    icons.classList.toggle("fa-moon")
    icons.classList.toggle("fa-sun")
}

barIcon.addEventListener("click", showUL);
closeIcon.addEventListener("click", hideUL);
darkModeToggle.addEventListener("click", makeDarkLight)
